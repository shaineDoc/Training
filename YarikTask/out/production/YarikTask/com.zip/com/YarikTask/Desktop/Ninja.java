package com.YarikTask.Desktop;

import java.util.Random;

public class Ninja {
    Double chakra;
    Double health;
    Double damageForAtack;
    public Ninja(Double chakra, Double health) {
        this.chakra = chakra;
        this.health = health;
    }

    public double[] jutsuAtack(String name) {
        Random random = new Random();
        double damage = 20 + (100 * random.nextInt()); // Случайное значение в диапазоне от 50 до 150
        double fixedValueChakra = 0;
        damage = damageForAtack;
        return new double[]{damageForAtack, fixedValueChakra};

    }
}