package com.YarikTask.Desktop;

public class Arena {
}
