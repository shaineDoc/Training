package com.YarikTask.Desktop;

import java.util.Locale;
import java.util.Random;

public class Gaara extends Ninja {
    public Gaara(Double chakra, Double health) {
        super(chakra, health);
    }
    Random random = new Random();

    @Override
    public double[] jutsuAtack(String name) {
        return super.jutsuAtack(name);
    }
}

