package com.YarikTask.Desktop;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Saske saske = new Saske(1000.00d);
        Gaara gaara = new Gaara(1000.00, 600d);
        saske.atack();

        gaara.health -= saske.damage;
        System.out.println("oops! Gaara  takes damage in " + saske.damage);
        System.out.println("Gaara, you helth = " + gaara.health);
        System.out.println("that you doing now, Saske ?");
        while (true) {
            saske.atack();
            System.out.println(saske.chakra);
            System.out.println("that you doing now ?");
        }

    }
}

